
class Authentication:

    def __init__(self, user_id: str, access_token: str):
        
        self.user_id = user_id
        self.access_token = access_token

        return self

